<?php
// Mendefinisikan Servernya
$server = "localhost";
$username = "root";
$password = "";
$database = "tokoku_db";

$koneksiku = mysqli_connect($server,$username,$password,"$database");
// Membuat kondisi apabila connect berhasil
if(!$koneksiku) {
    die ('Tidak dapat terhubung : '.mysqli_error());
}
// else {
//     echo "Koneksi Berhasil";
// }
?>