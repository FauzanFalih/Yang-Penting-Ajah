<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EDIT DATA</title>
</head>
<body>
<h3>EDIT DATA</h3>

<form action="tampildata.php" method="post">
        <label>KODE BARANG</label>
        <input type="text" name = "kdbarang"/><br>
        <label>NAMA BARANG</label>
        <input type="text" name = "nmbarang"/><br>
        <label>HARGA BELI</label>
        <input type="text" name = "belibarang"/><br>
        <label>HARGA JUAL</label>
        <input type="text" name = "jualbarang"/><br>
        <label>STOK BARANG</label>
        <input type="text" name = "stkbarang"/><br>
        <td><input type="hidden" name="id" value=<?php echo $_GET['id'];?>></td>
        <p>
            <button type="submit" value="kirim">KIRIM</button>
        </p>
    </form>

</body>
</html>