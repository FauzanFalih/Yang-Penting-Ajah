
<input type="hidden" name="id" value="<?php echo $data['id'] ?>">
<?php
        include 'koneksi.php';


       $edit = mysqli_query("UPDATE user SET kdbarang='$kdbarange', nmbarang='$nmbarange', 
                    belibarang='$belibarange', jualbarang='$jualbarange', stkbarang='$stkbarange'
                     WHERE id='$data'");

header("location:index.php?pesan=update");

     ?>