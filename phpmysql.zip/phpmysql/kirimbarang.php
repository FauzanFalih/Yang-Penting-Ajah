<?php
include 'koneksi.php';

$kdbarange = $_POST ['kdbarang'];
$nmbarange = $_POST ['nmbarang'];
$belibarange = $_POST ['belibarang'];
$jualbarange = $_POST ['jualbarang'];
$stkbarange = $_POST ['stkbarang'];
$data = $_POST ['id'];

$datakirim = ("INSERT INTO tbl_barang (
    kd_barang,nama_barang,harga_beli,harga_jual,stok_barang)
    VALUES ('$kdbarange','$nmbarange','$belibarange','$jualbarange','$stkbarange')");

$hasilkirim = mysqli_query($koneksiku,$datakirim);

if($hasilkirim) {
    echo "<script>alert('Data berhasil di simpan.');</script>";
} else {
    die ("Query gagal dijalankan :".mysqli_errno($koneksiku)."-".mysqli_error($koneksiku));
}
?>