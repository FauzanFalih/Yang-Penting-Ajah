<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tampil Data Barang</title>
</head>
<body>
    <table border = '1' width= '800'>
        <h2>Data Barang</h2>
        <br>
        <a href="inputbarang.html">
            <button type="click" value="click">Tambah Data</button>
        </a>
        </br>
        <tr>
            <th>NO</th>
            <th>KODE BARANG</th>
            <th>NAMA BARANG</th>
            <th>HARGA BELI</th>
            <th>HARGA JUAL</th>
            <th>STOK BARANG</th>
            <th>AKSI</th>
        </tr>

        <?php
        
        include 'koneksi.php';

        $nourut = 1;

        $tampilkandata = "SELECT*FROM tbl_barang ORDER BY kd_barang";
        $hasil = mysqli_query($koneksiku, $tampilkandata);
        while($data = mysqli_fetch_array ($hasil))
       {
     ?>
         <tr>
            <td><?php echo $nourut++; ?></td>
            <td><?php echo $data['kd_barang']; ?></td>
            <td><?php echo $data['nama_barang']; ?></td>
            <td><?php echo $data['harga_beli']; ?></td>
            <td><?php echo $data['harga_jual']; ?></td>
            <td><?php echo $data['stok_barang']; ?></td>
         
        <td>
            <a href="editdata.php?kd_barang=<?php echo $data['kd_barang']?>">EDIT</a> ||
            <a href='hapusbarang.php?kd_barang=$data[kd_barang]'>DELETE</a>
         </td>
         </tr> 

        <?php
       }
        ?>

    </table>
</body>
</html>