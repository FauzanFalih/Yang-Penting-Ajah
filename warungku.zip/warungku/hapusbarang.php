<?php
include_once("koneksi.php");

$kdbarang=$_GET['kd_barang'];

$tampilkandata=mysqli_query($koneksiku, "DELETE FROM tbl_barang WHERE kd_barang=$kdbarang");

header("Location:tampilbarang.php");
mysqli_close($koneksiku);
?>