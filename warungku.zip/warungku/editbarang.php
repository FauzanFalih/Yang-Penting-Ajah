<?php
include_once("koneksi.php");

if(isset($_POST['update'])) {
    $kdbarange=$_POST['kdbarang'];
    $namabarange=$_POST['namabarang'];
    $hargabeline=$_POST['hargabeli'];
    $hargajuale=$_POST['hargajual'];
    $stokbarange=$_POST['stokbarang'];

    $editnya=mysqli_query($koneksiku, "UPDATE tbl_barang
    SET nama_barang='$namabarange',harga_beli='$hargabeline',
    harga_jual='$hargajuale',stok_barang='$stokbarange' WHERE kd_barang=$kdbarange");

    header("Location:tampilbarang.php");
}
?>

<?php
$kdbarange=$_GET['kd_barang'];

$tampilkandata=mysqli_query($koneksiku, "SELECT * FROM tbl_barang WHERE kd_barang=$kdbarange");

while($datane=mysqli_fetch_array($tampilkandata)) {
    $namabarange=$datane['nama_barang'];
    $hargabeline=$datane['harga_beli'];
    $hargajuale=$datane['harga_jual'];
    $stokbarange=$datane['stok_barang'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Data Barang</title>
</head>
<body>
    <h2><a href="tampilbarang.php">Data Barang</a></h2>
    <br/>

    <form name="updatebarang" method="post" action="editbarang.php">
        <table border="0">
            <tr>
                <td>KODE BARANG</td>
                <td><input type="hidden" name="kdbarang" value=<?php echo $_GET['kd_barang'];?>></td>
            </tr>
            <tr>
                <td>NAMA BARANG</td>
                <td><input type="text" name="namabarang" value=<?php echo $namabarange;?>></td>
            </tr>
            <tr>
                <td>HARGA BELI</td>
                <td><input type="text" name="hargabeli" value=<?php echo $hargabeline;?>></td>
            </tr>
            <tr>
                <td>HARGA JUAL</td>
                <td><input type="text" name="hargajual" value=<?php echo $hargajuale;?>></td>
            </tr>
            <tr>
                <td>STOK BARANG</td>
                <td><input type="text" name="stokbarang" value=<?php echo $stokbarange;?>></td>
            </tr>
                <td><input type="submit" name="update" value="Update"></td>
                <td><a href="tampilbarang.php">
                <input type="button" name="cancel" value="Cancel">
                </a>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>