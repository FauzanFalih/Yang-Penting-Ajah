<?php
include_once("koneksi.php");

$tampilkandata = mysqli_query($koneksiku, "SELECT * FROM tbl_barang ORDER BY kd_barang ASC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tampil Data Barang</title>
</head>
<body>
    <table border = '1' width= '80%'>
        <h2>Data Barang</h2>
        <br>
        <a href="inputbarang.php">
            <button type="click" value="click">Tambah Data Barang</button>
        </a>
        </br>
        <tr>
            <th>NO</th>
            <th>KODE BARANG</th>
            <th>NAMA BARANG</th>
            <th>HARGA BELI</th>
            <th>HARGA JUAL</th>
            <th>STOK BARANG</th>
            <th>AKSI</th>
        </tr>

        <?php
        
        include 'koneksi.php';

        $no = 1;

        while($datane = mysqli_fetch_array ($tampilkandata))
       {
        echo "<tr>";
        echo "<td>".$no++."</td>";
        echo "<td>".$datane['kd_barang']."</td>";
        echo "<td>".$datane['nama_barang']."</td>";
        echo "<td>".$datane['harga_beli']."</td>";
        echo "<td>".$datane['harga_jual']."</td>";
        echo "<td>".$datane['stok_barang']."</td>";

        echo "<td><a href='editbarang.php?kd_barang=$datane[kd_barang]'>
        <button type='click' value='click'>Edit</a></button>||
        <a href='hapusbarang.php?kd_barang=$datane[kd_barang]'>
        <button type='click' value='click'>Delete</a></button>
        </td></tr>";
       }
       mysqli_close($koneksiku);
        ?>

    </table>
</body>
</html>