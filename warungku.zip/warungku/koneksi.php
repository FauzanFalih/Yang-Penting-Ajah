<?php
// Mendefinisikan Servernya
$server = "localhost";
$username = "root";
$password = "";
$database = "db_warungku";

$koneksiku = mysqli_connect($server,$username,$password,"$database");
// Membuat kondisi apabila connect berhasil
if(!$koneksiku) {
    die ('Tidak dapat terhubung : '.mysqli_error());
}
if(!$koneksiku) {
    die ('Tidak dapat terhubung : '.mysqli_error());
}
// else {
//     echo "Koneksi Berhasil";
// }
?>