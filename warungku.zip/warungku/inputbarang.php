<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Barang</title>
</head>
<body>
    <form action="inputbarang.php" method="post" name="inputbarang">
        <table width="25%" border="0">
            <tr>
                <td>KODE BARANG</td>
                <td><input type="text" name = "kdbarang"/></td>
            </tr>
            <tr>
                <td>NAMA BARANG</td>
                <td><input type="text" name = "nmbarang"/></td>
            </tr>
            <tr>
                <td>HARGA BELI</td>
                <td><input type="text" name = "hargabeli"/></td>
            </tr>
            <tr>
                <td>HARGA JUAL</td>
                <td><input type="text" name = "hargajual"/></td>
            </tr>
            <tr>
                <td>STOK BARANG</td>
                <td><input type="text" name = "stokbarang"/></td>
            </tr>
            <tr>
                <td><br><input type="submit" name="simpan" value="SIMPAN"></td>
                <td><br>
                    <a href="tampilbarang.php">
                        <button type="button" value="batal">Cancel</button>
                    </a>
                </td>
            </tr>
        </table>
    </form>
    <?php
    if(isset($_POST['simpan'])) {
        $kdbarange = $_POST ['kdbarang'];
        $namabarange = $_POST ['nmbarang'];
        $belibarange = $_POST ['hargabeli'];
        $jualbarange = $_POST ['hargajual'];
        $stokbarange = $_POST ['stokbarang'];

        include_once("koneksi.php");

        $inputdata = mysqli_query($koneksiku,
        "INSERT INTO tbl_barang(kd_barang,nama_barang,harga_beli,harga_jual,stok_barang)
        VALUES ('$kdbarange','$namabarange','$belibarange','$jualbarange','$stokbarange')");

        echo "Data Barang Berhasil Disimpan";
        header("Location:tampilbarang.php");
    }
    ?>
</body>
</html>