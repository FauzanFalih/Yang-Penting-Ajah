<?php

//mendefinisikan variabel
//untuk menangkap inputbarang.html

$kdbarange = $_POST ['kodebarang'];
$namabarange = $_POST ['namabarang'];
$hargabarange = $_POST ['hargabarang'];
$jumlahbarange = $_POST ['jumlahbarang'];

//membuat proses perhitungan
$totalbarange = $hargabarange*$jumlahbarange;

//memanggil nama variable
 echo "Kode Barang : ",$kdbarange; 
 echo "<br>";
 echo "Nama Barang : ",$namabarange;
 echo "<br>";
 echo "Harga Barang : ",$hargabarange;
 echo "<br>";
 echo "Jumlah Barang : ",$jumlahbarange;
 echo "<br>";
 echo "Total Harga : ",$totalbarange;
 echo "<br>";
 
 if ($totalbarange >= 50000){
    $diskonbarange = (($totalbarange*10)/100);
    $totaldiskon = $totalbarange-$diskonbarange;
    echo "Anda mendapatkan diskon sebesar 10% karena Total Harga lebih dari Rp 50.000";
    echo "<br>";
    echo "Total Diskon : ",$diskonbarange;
    echo "<br>";
    echo "Total Harga Diskon : ",$totaldiskon;
} else {
    echo "<br>";
    echo "Anda tidak mendapatkan diskon 10% karena Total Harga kurang dari Rp 50.000";

} if ($jumlahbarange >=10){
    $diskontbarange = (($totalbarange*5)/100);
    $totaldiskont = $totalbarange-$diskontbarange;
    echo "<br>";
    echo "Anda mendapatkan tambahan diskon sebesar 5% karena jumlah barang lebih dari 10 jumlah";
    echo "<br>";
    echo "Total Diskon : ",$diskontbarange;
    echo "<br>";
    echo "Total Harga Diskon : ",$totaldiskont;
} else {
    echo "<br>";
    echo "Anda tidak mendapatkan tambahan diskon 5% karena jumlah barang kurang dari 10 jumlah";
}
    
//membuat tabel dan memasukkan datanya
echo "<p


</p>";
echo "<table border = '1'>";
echo "<tr>";
echo "<th> Kode Barang </th>";
echo "<th> Nama Barang </th>";
echo "<th> Harga Barang </th>";
echo "<th> Jumlah Barang </th>";
echo "<th> Total Harga </th>";
echo "</tr>";
echo "<td>",$kdbarange,"</td>";
echo "<td>",$namabarange,"</td>";
echo "<td>",$hargabarange,"</td>";
echo "<td>",$jumlahbarange,"</td>";
echo "<td>",$totalbarange,"</td>";
echo "</table>";

?>