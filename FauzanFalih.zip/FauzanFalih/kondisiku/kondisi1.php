<?php

$amogus = "cerah";
if ($amogus == "mendung"){
    echo "Saya akan turu";
}

?>