<?php

$amogus = "90";
if ($amogus >= "90"){
    echo "Anda Diluar Nalar";
} else if ($amogus >= "86"){
    echo "Anda Pro Player";
} else if ($amogus >= "76"){
    echo "Anda Normal";
} else {
    echo "Anda Noob";
}

?>