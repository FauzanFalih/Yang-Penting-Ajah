<?php

$amogus = "cerah";
if ($amogus == "mendung"){
    echo "Saya akan turu";
} else {
    echo "Saya tidak sus";
}

?>